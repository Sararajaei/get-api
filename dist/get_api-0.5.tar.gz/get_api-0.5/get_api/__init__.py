from get_api.handler import get_api

__all__ = ['get_api']
